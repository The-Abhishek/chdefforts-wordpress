<?php
/**
 * Email Body
 *
 * @author 		Easy Digital Downloads
 * @package 	Easy Digital Downloads/Templates/Emails
 * @version     2.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// {email} is replaced by the content entered in Downloads > Settings > Emails

?>
{email}
